package lib.kg.youtubeparccer.core.utils

const val part = "snippet,contentDetails"
const val channelId = "UCWOA1ZGywLbqmigxE4Qlvuw"